openerp.pos_merge = function(instance){

    var module = instance.point_of_sale;



    pos_merge_mo(instance, module);
   // pos_customer_at(instance, module);



};
